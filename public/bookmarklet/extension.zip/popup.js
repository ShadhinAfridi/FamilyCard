const DEFAULT_GEMINI_MODEL = 'gemini-3.5-flash-lite';
const MODEL_RATES = {
  'gemini-3.5-flash-lite': { label: 'Gemini 3.5 Flash-Lite', inM: 0.30, outM: 2.50, est1k: 1.11, rpm: '4K RPM / 150K RPD' },
  'gemini-3.8-flash': { label: 'Gemini 3.8 Flash', inM: 0.75, outM: 3.75, est1k: 2.53, rpm: '1K RPM / 10K RPD' },
  'gemini-4-argon': { label: 'Gemini 4 Argon', inM: 2.00, outM: 10.00, est1k: 6.50, rpm: '500 RPM / 5K RPD' },
  'gemini-3.1-flash-lite': { label: 'Gemini 3.1 Flash-Lite', inM: 0.25, outM: 1.50, est1k: 0.78, rpm: '4K RPM / 150K RPD' },
  'deepseek-flash': { label: 'DeepSeek Flash', offIn: 0.15, offOut: 0.60, peakIn: 0.30, peakOut: 1.20 }
};

function isDeepSeekPeakNow() {
  const d = new Date();
  const day = d.getUTCDay();
  if (day < 1 || day > 5) return false;
  const h = d.getUTCHours();
  return (h >= 1 && h < 4) || (h >= 6 && h < 10);
}

document.addEventListener('DOMContentLoaded', () => {
  const elProvider = document.getElementById('aiProvider');
  const elDefaultKeySlot = document.getElementById('defaultKeySlot');
  const elGeminiModel = document.getElementById('geminiModel');
  const elDeepSeekModel = document.getElementById('deepseekModel');
  const elCostCard = document.getElementById('popupCostCard');
  const elApiKey = document.getElementById('geminiApiKey');
  const elDeepSeekKey = document.getElementById('deepseekApiKey');
  const elServerUrl = document.getElementById('serverUrl');
  const elRoomCode = document.getElementById('roomCode');
  const elDeviceName = document.getElementById('deviceName');
  const elS5Mfs = document.getElementById('s5MfsAccount');
  const elS5Training = document.getElementById('s5Training');
  const elS5Trans = document.getElementById('s5TransCount');
  const elS5Abroad = document.getElementById('s5AbroadDefault');
  const elS5AutoFill = document.getElementById('s5AutoFill');
  const btnCopyRoomLink = document.getElementById('btnCopyRoomLink');
  const btnSave = document.getElementById('btnSave');

  function updateCostPreview(stats = null) {
    if (!elCostCard) return;
    const strategy = elProvider ? elProvider.value : 'economy';
    const keySlot = elDefaultKeySlot ? elDefaultKeySlot.value : 'auto';
    const gemId = elGeminiModel ? elGeminiModel.value : DEFAULT_GEMINI_MODEL;
    const gem = MODEL_RATES[gemId] || MODEL_RATES[DEFAULT_GEMINI_MODEL];
    const peak = isDeepSeekPeakNow();
    const dsIn = peak ? 0.30 : 0.15;
    const dsOut = peak ? 1.20 : 0.60;
    const ds1k = peak ? 0.76 : 0.38;

    const useDeepSeekPrimary = strategy === 'deepseek' || (keySlot === 'deepseek' && (strategy === 'economy' || strategy === 'auto'));
    const primaryLine = useDeepSeekPrimary
      ? `<b>সক্রিয়:</b> DeepSeek Flash (${peak ? '🟠 Peak' : '🟢 Off-Peak'}) — <b>~$${ds1k.toFixed(2)}</b> (~৳${Math.round(ds1k * 122)}) / ১,০০০ NID`
      : `<b>সক্রিয়:</b> ${gem.label} — <b>~$${gem.est1k.toFixed(2)}</b> (~৳${Math.round(gem.est1k * 122)}) / ১,০০০ NID (${gem.rpm})`;

    const spendLine = stats && stats.totalScans > 0
      ? `<br>💰 মোট খরচ: <b>$${Number(stats.totalUsd || 0).toFixed(5)}</b> (~৳${(Number(stats.totalUsd || 0) * 122).toFixed(2)}) • ${stats.totalScans} স্ক্যান`
      : `<br>📉 তুলনা: DeepSeek $${dsIn}/$${dsOut} প্রতি 1M | ${gem.label} $${gem.inM}/$${gem.outM} প্রতি 1M`;

    elCostCard.innerHTML = `${primaryLine}${spendLine}`;
  }

  chrome.storage.sync.get([
    'aiProvider', 'defaultKeySlot', 'geminiModel', 'deepseekModel', 'geminiApiKey',
    'deepseekApiKey', 'serverUrl', 'roomCode', 'deviceName', 'fc_model_default_v2',
    's5MfsAccount', 's5Training', 's5TransCount', 's5AbroadDefault', 's5AutoFill'
  ], (res) => {
    if (res.aiProvider && elProvider) elProvider.value = res.aiProvider;
    if (res.defaultKeySlot && elDefaultKeySlot) elDefaultKeySlot.value = res.defaultKeySlot;
    let resolvedGemModel = res.geminiModel || DEFAULT_GEMINI_MODEL;
    if (!res.fc_model_default_v2) {
      if (!res.geminiModel || res.geminiModel === 'gemini-3.1-flash-lite') {
        resolvedGemModel = DEFAULT_GEMINI_MODEL;
      }
      chrome.storage.sync.set({ geminiModel: resolvedGemModel, fc_model_default_v2: '1' });
    }
    if (elGeminiModel) elGeminiModel.value = MODEL_RATES[resolvedGemModel] ? resolvedGemModel : DEFAULT_GEMINI_MODEL;
    if (res.deepseekModel && elDeepSeekModel) elDeepSeekModel.value = res.deepseekModel;
    if (res.geminiApiKey) elApiKey.value = res.geminiApiKey;
    if (res.deepseekApiKey && elDeepSeekKey) elDeepSeekKey.value = res.deepseekApiKey;
    if (res.serverUrl) elServerUrl.value = res.serverUrl;
    if (res.roomCode) elRoomCode.value = res.roomCode;
    if (res.deviceName && elDeviceName) elDeviceName.value = res.deviceName;
    if (res.s5MfsAccount && elS5Mfs) elS5Mfs.value = res.s5MfsAccount;
    if (res.s5Training && elS5Training) elS5Training.value = res.s5Training;
    if (res.s5TransCount && elS5Trans) elS5Trans.value = res.s5TransCount;
    if (res.s5AbroadDefault && elS5Abroad) elS5Abroad.value = res.s5AbroadDefault;
    if (res.s5AutoFill !== undefined && elS5AutoFill) elS5AutoFill.checked = Boolean(res.s5AutoFill);
    chrome.storage.local.get(['fcOcrCostStats'], (loc) => {
      updateCostPreview(loc?.fcOcrCostStats || null);
    });
  });

  [elProvider, elDefaultKeySlot, elGeminiModel, elDeepSeekModel].forEach((el) => {
    if (el) el.addEventListener('change', () => updateCostPreview());
  });

  if (btnCopyRoomLink) {
    btnCopyRoomLink.addEventListener('click', async () => {
      const r = (elRoomCode.value.trim() || 'FC-101').toUpperCase().replace(/[^A-Z0-9_-]/g, '') || 'FC-101';
      const link = `https://familycard.afridi.app/?room=${encodeURIComponent(r)}`;
      try {
        await navigator.clipboard.writeText(link);
        btnCopyRoomLink.textContent = '✅ রুম লিংক কপি হয়েছে!';
      } catch (_) {
        btnCopyRoomLink.textContent = link;
      }
      setTimeout(() => { btnCopyRoomLink.textContent = '🔗 রুম লিংক কপি (ফোনে খুলুন)'; }, 1800);
    });
  }

  btnSave.addEventListener('click', () => {
    const aiProvider = elProvider ? elProvider.value : 'economy';
    const defaultKeySlot = elDefaultKeySlot ? elDefaultKeySlot.value : 'auto';
    const geminiModel = elGeminiModel ? elGeminiModel.value : DEFAULT_GEMINI_MODEL;
    const deepseekModel = elDeepSeekModel ? elDeepSeekModel.value : 'deepseek-flash';
    const geminiApiKey = elApiKey.value.trim();
    const deepseekApiKey = elDeepSeekKey ? elDeepSeekKey.value.trim() : '';
    const serverUrl = elServerUrl.value.trim() || 'http://localhost:3000';
    const roomCode = ((elRoomCode.value.trim() || 'FC-101').toUpperCase().replace(/[^A-Z0-9_-]/g, '') || 'FC-101');
    const deviceName = (elDeviceName ? elDeviceName.value.trim() : '') || 'পিসি-এক্সটেনশন';
    const s5MfsAccount = elS5Mfs ? elS5Mfs.value : 'নগদ';
    const s5Training = elS5Training ? elS5Training.value : 'না';
    const s5TransCount = elS5Trans ? elS5Trans.value : '০';
    const s5AbroadDefault = elS5Abroad ? elS5Abroad.value : '০';
    const s5AutoFill = elS5AutoFill ? elS5AutoFill.checked : true;

    chrome.storage.sync.set({
      aiProvider, defaultKeySlot, geminiModel, deepseekModel, geminiApiKey, deepseekApiKey,
      serverUrl, roomCode, deviceName,
      s5MfsAccount, s5Training, s5TransCount, s5AbroadDefault, s5AutoFill
    }, () => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
          chrome.tabs.sendMessage(tabs[0].id, {
            action: 'config_updated',
            aiProvider,
            defaultKeySlot,
            geminiModel,
            deepseekModel,
            geminiApiKey,
            deepseekApiKey,
            serverUrl,
            roomCode,
            deviceName,
            s5MfsAccount,
            s5Training,
            s5TransCount,
            s5AbroadDefault,
            s5AutoFill
          }, () => {
            if (chrome.runtime.lastError) {}
          });
        }
      });
      btnSave.textContent = 'ডিফল্ট সংরক্ষিত হয়েছে! ✓';
      setTimeout(() => {
        btnSave.textContent = 'সেটিংস সংরক্ষণ করুন';
      }, 1500);
    });
  });
});
